package com.example.test_json1;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class MainActivity extends AppCompatActivity {

    Button button;
    TextView mytest;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mytest = (TextView) findViewById(R.id.text_result);
        button = (Button) findViewById(R.id.btn_parse);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new GoodTask().execute(" https://data.taipei/#/dataset/detail?id=bcf11ef9-9855-4ee3-8750-ca3df5aaf6c4");
            }
        });
    }

    class GoodTask extends AsyncTask<String, Integer, String> {
        // <傳入參數, 處理中更新介面參數, 處理後傳出參數>
        private static final int TIME_OUT = 1000;

        String jsonString1 = "";

        @Override
        protected String doInBackground(String... countTo) {
            // TODO Auto-generated method stub
            // 再背景中處理的耗時工作
            try{
                HttpURLConnection conn = null;
                URL url = new URL(countTo[0]);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.connect();
                // 讀取資料
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        conn.getInputStream(), "UTF-8"));
                jsonString1 = reader.readLine();
                reader.close();

                if (Thread.interrupted()) {
                    throw new InterruptedException();

                }
                if (jsonString1.equals("")) {
                    Thread.sleep(1000);
                }
            }

            catch(Exception e)
            {
                e.printStackTrace();
                return "網路中斷"+e;
            }

            return jsonString1;
        }


        String [] tital;
        String [] id;
        public void onPostExecute(String result )
        { super.onPreExecute();
            // 背景工作處理完"後"需作的事

            // JSONObject obj;
            try {
                //  obj = new JSONObject(result);
                //如果傳來的json是物件，且有給名字比如:data:{}才會使用obj.getString(“data”)
                // String data = obj.getString("data");
                //這裡傳來的是JSON陣列，因此要把剛剛撈到的字串轉換為JSON陣列
                JSONArray dataArray = new JSONArray(result);
                //先宣告tital跟id的字串陣列來存放等等要拆解的資料
                tital = new String [dataArray.length()];
                id = new String [dataArray.length()];

                //因為data陣列裡面有好多個JSON物件，因此利用for迴圈來將資料抓取出來
                //因為不知道data陣列裡有多少物件，因此我們用.length()這個方法來取得物件的數量
                for (int i = 0; i < dataArray.length(); i++) {
                    //接下來這兩行在做同一件事情，就是把剛剛JSON陣列裡的物件抓取出來
                    //並取得裡面的字串資料
                    //dataArray.getJSONObject(i)這段是在講抓取data陣列裡的第i個JSON物件
                    //抓取到JSON物件之後再利用.getString(“欄位名稱”)來取得該項value

                    tital[i] = dataArray.getJSONObject(i).getString("Tital");
                    id[i] = dataArray.getJSONObject(i).getString("Id");
                }
            }
            catch (JSONException e) {e.printStackTrace();
            }
            //step1:
            //mytest.setText("JSON:\r\n"+ result);
            //step2:
            mytest.setText("JSON:\r\n  tital:"+  tital[0]+"\r\n");


        }
        @Override
        protected void onProgressUpdate(Integer... values) {
            // TODO Auto-generated method stub
            super.onProgressUpdate(values);
            // 背景工作處理"中"更新的事

        }

    }
}